
<div class="list-group">
  <a href="#" class="list-group-item active">
    <h4>Halaman <strong>Dashboard</strong></h4><?php  // echo $row_rs_profile_admin['nama_lengkap']; ?>
  </a>
  <a href="?page=view/admin" class="list-group-item">Admin</a>
  <a href="?page=view/pesan" class="list-group-item">Pesan Masuk</a>
  <a href="?page=view/kategori" class="list-group-item">Kategori</a>
  <a href="?page=view/kota" class="list-group-item">Kota</a>  
  <a href="?page=view/kustomer" class="list-group-item">Kustomer</a>
  <a href="?page=view/modul" class="list-group-item">Modul</a>
  <a href="?page=view/pemesanan" class="list-group-item">Pemesanan</a>
  <a href="?page=view/pemesanan_detail" class="list-group-item">Pemesanan Detail</a>
  <a href="?page=view/laporan" class="list-group-item">Laporan</a>    
  <a href="?page=view/produk" class="list-group-item">Produk</a>      
  <a href="?page=view/slider" class="list-group-item">Slider</a>  
  <a href="<?php echo $logoutAction; ?>" class="list-group-item">Log Out</a>  
    
</div>